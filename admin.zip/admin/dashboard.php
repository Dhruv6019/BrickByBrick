<?php
require_once '../config.php';
session_start();

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

// Handle property approval/rejection
if (isset($_POST['action']) && isset($_POST['property_id'])) {
    $action = $_POST['action'];
    $property_id = (int)$_POST['property_id'];
    
    if ($action === 'approve' || $action === 'reject') {
        $status = $action === 'approve' ? 'approved' : 'rejected';
        $sql = "UPDATE properties SET status = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('si', $status, $property_id);
        $stmt->execute();
    }
}

// Fetch pending properties
$sql = "SELECT p.*, u.full_name as seller_name, pi.image_path 
FROM properties p 
LEFT JOIN users u ON p.seller_id = u.id 
LEFT JOIN property_images pi ON p.id = pi.property_id AND pi.is_primary = 1 
WHERE p.status = 'pending' 
ORDER BY p.created_at DESC";
$result = $conn->query($sql);

// Fetch user statistics
$stats_sql = "SELECT 
    (SELECT COUNT(*) FROM properties WHERE status = 'pending') as pending_properties,
    (SELECT COUNT(*) FROM properties WHERE status = 'approved') as approved_properties,
    (SELECT COUNT(*) FROM users WHERE user_type = 'user') as total_users";
$stats = $conn->query($stats_sql)->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Real Estate</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <nav class="col-md-3 col-lg-2 d-md-block bg-dark sidebar collapse">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active text-white" href="dashboard.php">
                                <i class="fas fa-user-gear"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="users.php">
                                <i class="fas fa-users"></i> Users
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="properties.php">
                                <i class="fas fa-building"></i> Properties
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="\newreal\index.php">
                                <i class="fas fa-home"></i> Home
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link text-white" href="../logout.php">
                                <i class="fas fa-sign-out-alt"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Dashboard</h1>
                </div>

                <div class="row mb-4">
                    <div class="col-md-4">
                        <div class="card bg-primary text-white">
                            <div class="card-body">
                                <h5 class="card-title">Pending Properties</h5>
                                <h2><?php echo $stats['pending_properties']; ?></h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card bg-success text-white">
                            <div class="card-body">
                                <h5 class="card-title">Approved Properties</h5>
                                <h2><?php echo $stats['approved_properties']; ?></h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card bg-info text-white">
                            <div class="card-body">
                                <h5 class="card-title">Total Users</h5>
                                <h2><?php echo $stats['total_users']; ?></h2>
                            </div>
                        </div>
                    </div>
                </div>

                <h2>Pending Properties</h2>
                <!-- Search input for pending properties -->
                <div class="row mb-3">
                    <div class="col-md-6">
                        <input type="text" id="propertySearch" class="form-control" placeholder="Search properties by title, seller, or location...">
                    </div>
                </div>
                
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Image</th>
                                <th>Title</th>
                                <th>Seller</th>
                                <th>Price</th>
                                <th>Location</th>
                                <th>Type</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($property = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $property['id']; ?></td>
                                <td>
                                    <img src="<?php echo !empty($property['image_path']) ? '../uploads/properties/' . $property['image_path'] : '../images/default-property.svg'; ?>"
                                         alt="Property" class="admin-property-thumb">
                                </td>
                                <td><?php echo htmlspecialchars($property['title']); ?></td>
                                <td><?php echo htmlspecialchars($property['seller_name']); ?></td>
                                <td>$<?php echo number_format($property['price']); ?></td>
                                <td><?php echo htmlspecialchars($property['location']); ?></td>
                                <td><?php echo ucfirst($property['property_type']); ?></td>
                                <td>
                                    <form method="POST" class="d-inline">
                                        <input type="hidden" name="property_id" value="<?php echo $property['id']; ?>">
                                        <button type="submit" name="action" value="approve" 
                                                class="btn btn-success btn-sm status-change" data-property-id="<?php echo $property['id']; ?>" data-status="approve" data-bs-toggle="tooltip" title="Approve Property">
                                            <i class="fas fa-check"></i>
                                        </button>
                                        <button type="submit" name="action" value="reject" 
                                                class="btn btn-danger btn-sm status-change" data-property-id="<?php echo $property['id']; ?>" data-status="reject" data-bs-toggle="tooltip" title="Reject Property">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </form>
                                    <a href="../property.php?id=<?php echo $property['id']; ?>" 
                                       class="btn btn-info btn-sm" target="_blank" data-bs-toggle="tooltip" title="View Property">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../js/admin.js"></script>
</body>
</html>