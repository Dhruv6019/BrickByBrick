<?php
// Comparison bar component
?>
<div id="comparison-bar" class="comparison-bar fixed-bottom bg-white border-top py-2 d-none">
    <div class="container d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-center">
            <i class="fas fa-balance-scale me-2"></i>
            <span><strong id="comparison-count">0</strong> properties selected for comparison</span>
        </div>
        <div>
            <button id="view-comparison-btn" class="btn btn-primary btn-sm me-2">Compare Now</button>
            <button id="clear-comparison-btn" class="btn btn-outline-secondary btn-sm">Clear All</button>
        </div>
    </div>
</div>

<style>
.comparison-bar {
    box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);
    z-index: 1030;
}

.comparison-bar.show {
    display: flex !important;
}
</style>

<script>
// Initialize property comparison functionality
function initPropertyComparison() {
    const comparisonBar = document.getElementById('comparison-bar');
    const comparisonCount = document.getElementById('comparison-count');
    const viewComparisonBtn = document.getElementById('view-comparison-btn');
    const clearComparisonBtn = document.getElementById('clear-comparison-btn');
    
    // Get comparison list from localStorage
    let comparisonList = JSON.parse(localStorage.getItem('propertyComparison') || '[]');
    
    // Update UI based on current comparison list
    function updateComparisonUI() {
        comparisonCount.textContent = comparisonList.length;
        if (comparisonList.length > 0) {
            comparisonBar.classList.remove('d-none');
        } else {
            comparisonBar.classList.add('d-none');
        }
        
        // Update all comparison buttons on the page
        document.querySelectorAll('.compare-property-btn').forEach(btn => {
            const propertyId = btn.dataset.propertyId;
            btn.classList.toggle('active', comparisonList.includes(propertyId));
        });
    }
    
    // Initialize UI
    updateComparisonUI();
    
    // Handle comparison button clicks
    document.addEventListener('click', function(e) {
        if (e.target.closest('.compare-property-btn')) {
            const btn = e.target.closest('.compare-property-btn');
            const propertyId = btn.dataset.propertyId;
            
            const index = comparisonList.indexOf(propertyId);
            if (index === -1) {
                if (comparisonList.length < 4) {
                    comparisonList.push(propertyId);
                    btn.classList.add('active');
                } else {
                    alert('You can compare up to 4 properties at a time');
                    return;
                }
            } else {
                comparisonList.splice(index, 1);
                btn.classList.remove('active');
            }
            
            localStorage.setItem('propertyComparison', JSON.stringify(comparisonList));
            updateComparisonUI();
        }
    });
    
    // Handle view comparison button click
    viewComparisonBtn.addEventListener('click', function() {
        if (comparisonList.length < 2) {
            alert('Please select at least 2 properties to compare');
            return;
        }
        window.location.href = 'compare.php?properties=' + comparisonList.join(',');
    });
    
    // Handle clear comparison button click
    clearComparisonBtn.addEventListener('click', function() {
        comparisonList = [];
        localStorage.setItem('propertyComparison', JSON.stringify(comparisonList));
        updateComparisonUI();
    });
}

// Initialize comparison functionality
initPropertyComparison();
</script>