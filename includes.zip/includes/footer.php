<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-4 mb-4 mb-md-0">
                <h5>BrickByBrick</h5>
                <p class="mt-3">Your trusted partner in finding the perfect property. We make real estate simple and stress-free.</p>
                
            </div>
            <div class="col-md-2 mb-4 mb-md-0">
                <h5>Quick Links</h5>
                <ul class="list-unstyled footer-links">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="search.php">Properties</a></li>
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="contact.php">Contact</a></li>
                </ul>
            </div>
            <div class="col-md-3 mb-4 mb-md-0">
                <h5>Property Types</h5>
                <ul class="list-unstyled footer-links">
                    <li><a href="search.php?property_type=house">Houses</a></li>
                    <li><a href="search.php?property_type=apartment">Apartments</a></li>
                   
                    <li><a href="search.php?property_type=land">Land</a></li>
                </ul>
            </div>
            <div class="col-md-3">
                <h5>Contact Us</h5>
                <address class="mb-0">
                    <p><i class="fas fa-map-marker-alt me-2"></i> 123, Real Estate, Ahmedabad</p>
                    <p><i class="fas fa-phone-alt me-2"></i> 9876543210</p>
                    <p><i class="fas fa-envelope me-2"></i> info@brickbybrick.com</p>
                </address>
            </div>
        </div>
        <div class="copyright mt-4 pt-3 border-top">
            <p class="text-center mb-0 text-muted">&copy; <?php echo date('Y'); ?> BrickByBrick. All rights reserved.</p>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="js/main.js"></script>
<script src="js/enhanced-main.js"></script>
<script src="js/virtual-tour.js"></script>
