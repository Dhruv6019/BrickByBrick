/* Enhanced JavaScript for Real Estate Website */

$(document).ready(function() {
    // Sticky navbar on scroll
    $(window).scroll(function() {
        if ($(this).scrollTop() > 50) {
            $('.navbar').addClass('scrolled');
        } else {
            $('.navbar').removeClass('scrolled');
        }
    });

    // Handle favorite button clicks with improved feedback
    $('.favorite-btn').click(function() {
        const btn = $(this);
        btn.addClass('clicked');
        setTimeout(() => btn.removeClass('clicked'), 300);
    });

    // Custom toast notification system
    function showToast(message, type = 'info') {
        const toast = $(`<div class="toast-notification ${type}">${message}</div>`);
        $('body').append(toast);
        
        setTimeout(function() {
            toast.addClass('show');
        }, 100);
        
        setTimeout(function() {
            toast.removeClass('show');
            setTimeout(function() {
                toast.remove();
            }, 300);
        }, 3000);
    }

    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Property image preview with zoom effect
    $('.property-image-upload').change(function() {
        const input = this;
        const preview = $(this).siblings('.image-preview');

        if (input.files && input.files[0]) {
            const reader = new FileReader();
            
            reader.onload = function(e) {
                preview.attr('src', e.target.result).show();
                preview.addClass('zoom-in');
                setTimeout(() => preview.removeClass('zoom-in'), 500);
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    });

    // Animated counters for statistics
    function animateCounter() {
        $('.counter').each(function() {
            const $this = $(this);
            const countTo = parseInt($this.attr('data-count'));
            
            $({ countNum: 0 }).animate({
                countNum: countTo
            }, {
                duration: 2000,
                easing: 'swing',
                step: function() {
                    $this.text(Math.floor(this.countNum));
                },
                complete: function() {
                    $this.text(this.countNum.toLocaleString());
                }
            });
        });
    }

    // Trigger counter animation when element is in viewport
    const $counters = $('.counter');
    if ($counters.length) {
        const waypoint = new Waypoint({
            element: document.querySelector('.stats-section'),
            handler: function() {
                animateCounter();
                this.destroy();
            },
            offset: '80%'
        });
    }

    // Testimonial carousel
    if ($('.testimonial-carousel').length) {
        $('.testimonial-carousel').slick({
            dots: true,
            arrows: false,
            infinite: true,
            speed: 500,
            slidesToShow: 2,
            slidesToScroll: 1,
            autoplay: true,
            autoplaySpeed: 5000,
            responsive: [
                {
                    breakpoint: 992,
                    settings: {
                        slidesToShow: 1
                    }
                }
            ]
        });
    }

    // Neighborhood guide carousel
    if ($('.neighborhood-carousel').length) {
        $('.neighborhood-carousel').slick({
            dots: false,
            arrows: true,
            infinite: true,
            speed: 500,
            slidesToShow: 3,
            slidesToScroll: 1,
            autoplay: true,
            autoplaySpeed: 4000,
            prevArrow: '<button class="slick-prev"><i class="fas fa-chevron-left"></i></button>',
            nextArrow: '<button class="slick-next"><i class="fas fa-chevron-right"></i></button>',
            responsive: [
                {
                    breakpoint: 992,
                    settings: {
                        slidesToShow: 2
                    }
                },
                {
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 1
                    }
                }
            ]
        });
    }

    // Advanced property filtering
    $('#advanced-filter-toggle').click(function() {
        $('.advanced-filters').slideToggle(300);
        $(this).find('i').toggleClass('fa-chevron-down fa-chevron-up');
    });

    // Price range slider (if exists)
    const priceRange = document.getElementById('price-range');
    if (priceRange) {
        noUiSlider.create(priceRange, {
            start: [0, 1000000],
            connect: true,
            range: {
                'min': 0,
                'max': 1000000
            },
            format: {
                to: value => Math.round(value),
                from: value => Math.round(value)
            }
        });

        priceRange.noUiSlider.on('update', function(values) {
            document.getElementById('min-price').value = values[0];
            document.getElementById('max-price').value = values[1];
            document.getElementById('price-display').textContent = 
                `₹${Number(values[0]).toLocaleString()} - ₹${Number(values[1]).toLocaleString()}`;
        });
    }

    // Animate elements when they come into view
    $('.animate-on-scroll').each(function() {
        const $this = $(this);
        const animation = $this.data('animation') || 'fadeInUp';
        
        const waypoint = new Waypoint({
            element: $this[0],
            handler: function() {
                $this.addClass('animated ' + animation);
                this.destroy();
            },
            offset: '90%'
        });
    });

    // Property type filter buttons
    $('.property-type-filter').click(function() {
        const filterValue = $(this).data('filter');
        
        $('.property-type-filter').removeClass('active');
        $(this).addClass('active');
        
        if (filterValue === 'all') {
            $('.property-card').show();
        } else {
            $('.property-card').hide();
            $(`.property-card[data-type="${filterValue}"]`).show();
        }
    });

    // Back to top button functionality removed
});