/**
 * Admin panel JavaScript functionality
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    })

    // Confirm delete actions
    const deleteButtons = document.querySelectorAll('.delete-confirm');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            if (!confirm('Are you sure you want to delete this item? This action cannot be undone.')) {
                e.preventDefault();
            }
        });
    });

    // Handle property status changes
    const statusButtons = document.querySelectorAll('.status-change');
    statusButtons.forEach(button => {
        button.addEventListener('click', function(event) {
            const propertyId = this.getAttribute('data-property-id');
            const status = this.getAttribute('data-status');
            const statusText = status === 'approve' ? 'approve' : 'reject';
            
            if (confirm(`Are you sure you want to ${statusText} this property?`)) {
                // Form submission is handled by the button's form
            } else {
                event.preventDefault();
            }
        });
    });

    // Toggle sidebar on mobile
    const sidebarToggle = document.querySelector('#sidebarToggle');
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('show');
        });
    }

    // Property search functionality
    const propertySearchInput = document.querySelector('#propertySearch');
    if (propertySearchInput) {
        propertySearchInput.addEventListener('keyup', function() {
            const searchValue = this.value.toLowerCase();
            const propertyRows = document.querySelectorAll('table tbody tr');
            
            propertyRows.forEach(row => {
                const title = row.querySelector('td:nth-child(3)').textContent.toLowerCase();
                const seller = row.querySelector('td:nth-child(4)').textContent.toLowerCase();
                const location = row.querySelector('td:nth-child(6)').textContent.toLowerCase();
                
                if (title.includes(searchValue) || seller.includes(searchValue) || location.includes(searchValue)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    }

    // Image preview on hover
    const propertyThumbs = document.querySelectorAll('.admin-property-thumb');
    propertyThumbs.forEach(thumb => {
        thumb.addEventListener('mouseenter', function() {
            const imgSrc = this.getAttribute('src');
            const previewDiv = document.createElement('div');
            previewDiv.classList.add('property-preview');
            previewDiv.innerHTML = `<img src="${imgSrc}" alt="Property Preview">`;
            document.body.appendChild(previewDiv);
            
            const rect = this.getBoundingClientRect();
            previewDiv.style.top = `${rect.top}px`;
            previewDiv.style.left = `${rect.right + 10}px`;
        });
        
        thumb.addEventListener('mouseleave', function() {
            const preview = document.querySelector('.property-preview');
            if (preview) {
                preview.remove();
            }
        });
    });

    // Add responsive table functionality
    const tables = document.querySelectorAll('.table-responsive table');
    if (window.innerWidth < 768) {
        tables.forEach(table => {
            const headerTexts = [];
            const headers = table.querySelectorAll('thead th');
            headers.forEach(header => {
                headerTexts.push(header.textContent.trim());
            });
            
            const rows = table.querySelectorAll('tbody tr');
            rows.forEach(row => {
                const cells = row.querySelectorAll('td');
                cells.forEach((cell, index) => {
                    if (headerTexts[index]) {
                        cell.setAttribute('data-label', headerTexts[index]);
                    }
                });
            });
        });
    }

    // Add form validation for admin forms
    const adminForms = document.querySelectorAll('.admin-form');
    adminForms.forEach(form => {
        form.addEventListener('submit', function(event) {
            let isValid = true;
            const requiredInputs = form.querySelectorAll('[required]');
            
            requiredInputs.forEach(input => {
                if (!input.value.trim()) {
                    isValid = false;
                    input.classList.add('is-invalid');
                    
                    // Create error message if it doesn't exist
                    let errorDiv = input.nextElementSibling;
                    if (!errorDiv || !errorDiv.classList.contains('invalid-feedback')) {
                        errorDiv = document.createElement('div');
                        errorDiv.classList.add('invalid-feedback');
                        errorDiv.textContent = 'This field is required';
                        input.parentNode.insertBefore(errorDiv, input.nextSibling);
                    }
                } else {
                    input.classList.remove('is-invalid');
                }
            });
            
            if (!isValid) {
                event.preventDefault();
            }
        });
    });
});