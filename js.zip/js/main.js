$(document).ready(function() {
    // Handle favorite button clicks
    $('.favorite-btn').click(function() {
        const btn = $(this);
        const propertyId = btn.data('property-id');
        
        $.ajax({
            url: 'ajax/toggle_favorite.php',
            type: 'POST',
            data: { property_id: propertyId },
            success: function(response) {
                const data = JSON.parse(response);
                if (data.success) {
                    btn.find('i').toggleClass('far fas');
                    btn.attr('title', data.is_favorite ? 'Remove from Favorites' : 'Add to Favorites');
                    showToast(data.message, 'success');
                } else {
                    showToast('Error updating favorite status', 'error');
                }
            },
            error: function() {
                showToast('Error updating favorite status', 'error');
            }
        });

        btn.addClass('clicked');
        setTimeout(() => btn.removeClass('clicked'), 300);
    });

    // Handle compare button clicks
    $('.compare-property-btn').click(function() {
        const btn = $(this);
        const propertyId = btn.data('property-id');
        let comparedProperties = JSON.parse(getCookie('comparedProperties') || '[]');
        
        if (btn.hasClass('active')) {
            comparedProperties = comparedProperties.filter(id => id !== propertyId);
            btn.removeClass('active');
            showToast('Property removed from comparison', 'info');
        } else {
            if (comparedProperties.length >= 4) {
                showToast('You can compare up to 4 properties at a time', 'warning');
                return;
            }
            comparedProperties.push(propertyId);
            btn.addClass('active');
            showToast('Property added to comparison', 'success');
        }
        
        document.cookie = `comparedProperties=${JSON.stringify(comparedProperties)};path=/`;
    });

    // Cookie helper function
    function getCookie(name) {
        const value = `; ${document.cookie}`;
        const parts = value.split(`; ${name}=`);
        if (parts.length === 2) return parts.pop().split(';').shift();
        return null;
    }

    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Property image preview
    $('.property-image-upload').change(function() {
        const input = this;
        const preview = $(this).siblings('.image-preview');

        if (input.files && input.files[0]) {
            const reader = new FileReader();
            
            reader.onload = function(e) {
                preview.attr('src', e.target.result).show();
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    });

    // Price range slider (if exists)
    const priceRange = document.getElementById('price-range');
    if (priceRange) {
        noUiSlider.create(priceRange, {
            start: [0, 1000000],
            connect: true,
            range: {
                'min': 0,
                'max': 1000000
            },
            format: {
                to: value => Math.round(value),
                from: value => Math.round(value)
            }
        });

        priceRange.noUiSlider.on('update', function(values) {
            document.getElementById('min-price').value = values[0];
            document.getElementById('max-price').value = values[1];
            document.getElementById('price-display').textContent = 
                `$${Number(values[0]).toLocaleString()} - $${Number(values[1]).toLocaleString()}`;
        });
    }
});