document.addEventListener('DOMContentLoaded', function() {
    const visitEnquiryForm = document.getElementById('visitEnquiryForm');
    
    if (visitEnquiryForm) {
        visitEnquiryForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form data
            const formData = new FormData(visitEnquiryForm);
            
            // Show loading state
            const submitButton = visitEnquiryForm.querySelector('button[type="submit"]');
            const originalButtonText = submitButton.innerHTML;
            submitButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Sending...';
            submitButton.disabled = true;
            
            // For demonstration purposes, we'll just simulate a successful submission
            // In a real application, you would send this data to the server using fetch or XMLHttpRequest
            setTimeout(function() {
                // Reset form
                visitEnquiryForm.reset();
                
                // Show success message
                const alertDiv = document.createElement('div');
                alertDiv.className = 'alert alert-success mt-3';
                alertDiv.role = 'alert';
                alertDiv.innerHTML = '<i class="fas fa-check-circle me-2"></i> Your visit request has been sent successfully! We will contact you shortly to confirm.';
                
                // Insert alert before the form
                visitEnquiryForm.parentNode.insertBefore(alertDiv, visitEnquiryForm);
                
                // Reset button
                submitButton.innerHTML = originalButtonText;
                submitButton.disabled = false;
                
                // Remove alert after 5 seconds
                setTimeout(function() {
                    alertDiv.remove();
                }, 5000);
            }, 1500);
        });
    }
});